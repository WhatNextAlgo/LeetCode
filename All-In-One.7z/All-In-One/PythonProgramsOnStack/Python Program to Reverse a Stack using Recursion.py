class Stack:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return self.items == []

    def push(self,data):
        self.items.append(data)

    def pop(self):
        return self.items.pop()

    def display(self):
        for data in self.items:
            print(data)

def insert_at_bottom(s,data):
    if s.is_empty():
        s.push(data)
    else:
        popped = s.pop()
        insert_at_bottom(s,data)
        s.push(popped)

def reverse_stack(s):
    if not s.is_empty():
        popped= s.pop()
        reverse_stack(s)
        insert_at_bottom(s,popped)
        


s = Stack()
data_list = input('Please enter the elements to push: ').split()
for data in data_list:
    s.push(int(data))
 
print('The stack:')
s.display()
reverse_stack(s)
print('After reversing:')
s.display()

    
