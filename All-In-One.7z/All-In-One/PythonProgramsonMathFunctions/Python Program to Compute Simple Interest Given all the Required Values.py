principal = float(input("Enter a principal: "))
rate = float(input("Enter a rate: "))
time = int(input("Enter a time: "))

SI  = (principal * rate * time)/100
print("Simple interest : ",SI) 