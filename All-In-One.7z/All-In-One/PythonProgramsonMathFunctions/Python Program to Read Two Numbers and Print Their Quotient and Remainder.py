a = int(input("Enter a: "))
b = int(input("Enter b: "))

remainder = a%b
quotient = a//b
print(f"remainder: {remainder}  and quotient = {quotient}")