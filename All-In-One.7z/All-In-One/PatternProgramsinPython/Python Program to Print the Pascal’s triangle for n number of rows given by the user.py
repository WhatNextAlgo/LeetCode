n = int(input("Enter NUmber: "))
a= []
for x in range(n):
    a.append([])
    a[x].append(1)
    for y in range(1,x):
        a[x].append(a[x-1][y-1]+a[x-1][y])

    if n != 0:
        a[x].append(1)

for x in range(n):
    print("   "*(n-x),end = " ",sep=" ")
    for y in range(0,x + 1):
        print('{0:6}'.format(a[x][y]),end=" ",sep=" ")
    print()
