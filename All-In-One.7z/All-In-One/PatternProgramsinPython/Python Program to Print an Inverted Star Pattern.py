n = int(input("Enter Number: "))

for x in range(n,0,-1):
    print((n-x)*" "+"*" * x)