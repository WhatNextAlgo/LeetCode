class TreeNode:
    def __init__(self,key):
        self.key = key
        self.children = []

    def add_children(self,node):
        self.children.append(node)
    

    def __str__(self,level=0):
        res = "  "*level + str(self.key) + "\n"
        for child in self.children:
            res += child.__str__(level + 1)

        return res

    def preorder(self,root ,lst =[]):
        if root is None:
            return []
        print(root.key)
        lst.append(root.key)
        for child in root.children:
            self.preorder(child)
        return lst



# tree = TreeNode('Drinks')
# hot = TreeNode('Hot')
# cold = TreeNode('Cold')
# tree.add_children(hot)
# tree.add_children(cold)

# tea = TreeNode('Tea')
# coffee = TreeNode('Coffee')
# hot.add_children(tea)
# hot.add_children(coffee)

# cola = TreeNode('cola')
# fanta = TreeNode('fanta')
# cold.add_children(cola)
# cold.add_children(fanta)

# print(tree)
# print(tree.preorder(tree))

t = TreeNode(1)
two = TreeNode(2)
three = TreeNode(3)
four = TreeNode(4)
five = TreeNode(5)
t.add_children(two)
t.add_children(three)
t.add_children(four)
t.add_children(five)

six = TreeNode(6)
seven = TreeNode(7)
three.add_children(six)
three.add_children(seven)

eight = TreeNode(8)
four.add_children(eight)


nine = TreeNode(9)
ten = TreeNode(10)
five.add_children(nine)
five.add_children(ten)

eleven = TreeNode(11)
seven.add_children(eleven)

twelve = TreeNode(12)
eight.add_children(twelve)

thirteen = TreeNode(13)
nine.add_children(thirteen)

fourteen = TreeNode(14)
eleven.add_children(fourteen)

print(t.preorder(t))



