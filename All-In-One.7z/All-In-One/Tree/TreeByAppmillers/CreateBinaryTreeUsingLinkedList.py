from logging import root


class TreeNode:
    def __init__(self,key):
        self.key = key
        self.left = None
        self.right = None




def preorder(rootNode):
    if not rootNode:
        return
    print(rootNode.key, end='--> ')
    preorder(rootNode.left)
    preorder(rootNode.right)

def inorder(rootNode):
    if not rootNode:
        return
    inorder(rootNode.left)
    print(rootNode.key, end = '--> ')
    inorder(rootNode.right)

def postorder(rootNode):
    if not rootNode:
        return
    postorder(rootNode.left)
    postorder(rootNode.right)
    print(rootNode.key, end = '--> ')

def levelorder(rootNode):
    if rootNode is None:
        return
    else:
        q = []
        q.append(rootNode)
        while q != []:
            poped = q.pop(0)
            print(poped.key, end ='--> ')
            if poped.left is not None:
                q.append(poped.left)
            if poped.right is not None:
                q.append(poped.right)

def search(rootNode,key):
    if rootNode is None:
        return "Binary Tree not exist."
    else:
        q = []
        q.append(rootNode)
        while q != []:
            poped = q.pop(0)
            if poped.key == key:
                return f'{key} node exist.'
            if poped.left is not None:
                    q.append(poped.left)
            if poped.right is not None:
                q.append(poped.right) 
        return f'{key} node doest not exist.'

def insert(rootNode,node):
    if rootNode is None:
        rootNode = node
        return "Successfully inserted"
    else:
        q = []
        q.append(rootNode)
        while q != []:
            poped = q.pop(0)
            if poped.left is None:
                poped.left = node
                return "Successfully inserted"
            else:
                q.append(poped.left)
            if poped.right is None:
                poped.right = node
                return "Successfully inserted"
            else:
                q.append(poped.right) 

def getDeepestNode(rootNode):
    if not rootNode:
        return
    else:
        q = []
        q.append(rootNode)
        while q != []:
            poped = q.pop(0)
            if poped.left is not None:
                q.append(poped.left)
            
            if poped.right is not None:
                q.append(poped.right)
        deepestNode = poped
        return deepestNode

def deleteDeepestNode(rootNode,dNode):
    if not rootNode:
        return
    else:
        q = []
        q.append(rootNode)
        while q != []:
            poped = q.pop(0)
            if poped.key is dNode:
                poped.key = None
                return

bt = TreeNode('Drinks')
bt.left = TreeNode("Hot")
bt.right = TreeNode('Cold')
bt.left.left = TreeNode("Tea")
bt.left.right = TreeNode('Coffee')
bt.right.left = TreeNode("Fanta")
bt.right.right = TreeNode('Cola')
print()
print("DeepestNode :")
print(getDeepestNode(bt))
print("Preorder :")
preorder(bt)
print()
print("Inorder :")
inorder(bt)
print()
print("Postorder :")
postorder(bt)
print()
print("levelorder :")
levelorder(bt)
print()
print("search Node: ")
print(search(bt,'Soda'))
print()
print(insert(bt,TreeNode("Green Tea")))
levelorder(bt)


