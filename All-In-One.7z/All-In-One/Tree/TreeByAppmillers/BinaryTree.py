from platform import node


class Node:
    def __init__(self,key):
        self.key = key
        self.left = None
        self.right = None


    def insert(self,data):
        if self.key > data:
            if self.left is None:
                self.left = Node(data)
            else:
                self.left.insert(data)
        elif self.key < data:
            if self.right is None:
                self.right = Node(data)
            else:
                self.right.insert(data)

    def inorder(self):
        if self.left is not None:
            self.left.inorder()
        print(self.key, end= ' ')
        if self.right is not None:
            self.right.inorder()

class BinaryTree:
    def __init__(self):
        self.root = None

    def insert(self,data):
        if self.root is None:
            self.root = Node(data)
        else:
            self.root.insert(data)

    def inorder(self):
        if self.root is not None:
            self.root.inorder()


bt = BinaryTree()
bt.insert(1)
bt.insert(2)
bt.insert(3)
bt.insert(4)
bt.insert(5)
bt.inorder()