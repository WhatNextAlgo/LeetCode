celsius=int(input("Enter the temperature in celcius:"))

f = (celsius * 1.8) + 32
print("Temperature in farenheit is:",f)

#fahrenheit to celsius

c = (f -32) * 5/9

print("Temperature in celsius is:", c)