class A(object):
    def __init__(self) -> None:
        self.A = 1
        self.B = 2

    

obj = A()
print(obj.__dict__)