d={'A':10,'B':10,'C':239}

total = 1
for x in d.values():
    total *= x

print("total : ",total)