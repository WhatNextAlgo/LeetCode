d={'A':100,'B':540,'C':239}

print("Total sum of values in the dictionary:")
print(sum(d.values()))