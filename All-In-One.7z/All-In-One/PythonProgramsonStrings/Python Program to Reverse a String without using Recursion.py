s = input("Enter String: ")

print(s[::-1])