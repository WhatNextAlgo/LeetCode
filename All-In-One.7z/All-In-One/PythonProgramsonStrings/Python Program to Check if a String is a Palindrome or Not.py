s = input("Enter String: ")

if (s == s[::-1]):
    print("The string is a palindrome")
else:
      print("The string isn't a palindrome")