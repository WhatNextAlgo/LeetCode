s = input("Enter String: ")

count = 0

for x in s:
    count = count + 1

print(f"Count of given string = {s}  is {count}")