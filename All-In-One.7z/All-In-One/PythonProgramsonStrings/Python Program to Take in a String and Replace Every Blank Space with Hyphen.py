s = input(r"Enter String: ")

new_str = "-".join(s.split(" "))



print("Modified String: ",new_str)