for x in range(1, 50):
    if (x % 2 != 0) & (x % 3 != 0):
        print(x, end = " ")