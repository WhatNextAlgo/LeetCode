n  =  int(input("Enter Number"))

if (n > 0):
    print(f"{n} is positive number")
else:
    print(f"{n} is negative number")