n = input("Enter Number : ")

comp = int(n) + int(n * 2) + int(n * 3)
print("The value is:",comp)