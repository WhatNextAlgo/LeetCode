n=int(input("Enter the number to print the tables for:"))
for x in range(1,11):
    print(f"{n} x {x} = {n * x} ")