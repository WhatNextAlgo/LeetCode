"""
MATH SOLUTION : R // 2 (R + 1) = N

"""

class Solution:
    def arrangeCoins(self, n: int) -> int:
        l , r = 1 , n
        res =0
        while l <= r:
            mid = l + ((r - l)//2)
            coins = (mid/2) * (mid + 1)
            if coins > n:
                r = mid - 1
            else:
                l = mid + 1
                res = max(mid,res)
        return res

    def arrangeCoins(self, n: int) -> int:
        left, right = 0 , n
        while right - left >= 0:
            mid = (right + left)//2
            num_com = mid * (mid + 1)//2
            if num_com == n:
                return mid
            elif num_com > n:
                right = mid -1
            else:
                left = mid +1
        return right



s = Solution()
print(s.arrangeCoins(n = 5))