class Solution:
    def isPerfectSquare(self, num: int) -> bool:
        end = num
        start = 0

        while end - start >= 0:
            mid = start + ((end - start)//2)

            if mid * mid < num:
                start = mid + 1
            elif mid * mid > num:
                end = mid -1
            else:
                return True
        return False

s = Solution()
print(s.isPerfectSquare(64))