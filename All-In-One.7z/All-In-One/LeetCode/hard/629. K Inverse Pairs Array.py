class Solution:
    def kInversePairs(self, n: int, k: int) -> int:
        c

s  = Solution()
print(s.kInversePairs(n = 6, k = 4))