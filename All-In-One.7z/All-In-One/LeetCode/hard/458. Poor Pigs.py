from math import ceil, log2

# Intuition
# We can come up with the solution starting from simple scenarios

# 1 or 2 buckets --> 1 pig is enough (right, this one's trivial)
# 3 or 4 buckets --> 2 pigs are enough, because the task is similar to identifying buckets using
# bucket1 : noone drinks it
# bucket2 : pig#1 drinks this bucket
# bucket3 : pig#2 drinks this bucket
# bucket4 : both pigs drink it
# i.e. we can use log2(B) pigs to identify each bucket by looking atwhich pigs have died and what they drank i.e. 1
#https://leetcode.com/problems/poor-pigs/discuss/2386378/python-binary-(kill-mosquitoes-instead-of-pigs)
#https://github.com/qobiljon

class Solution:
    def poorPigs(self, buckets: int, minutesToDie: int, minutesToTest: int) -> int:
        tmp = log2(buckets) # number of pigs for one shot
        t = ceil(minutesToTest/minutesToDie) # number of tests we can conduct

        if t == 1: return ceil(tmp) # one shot is the answer
        return ceil(tmp / log2(t+1)) # re-use pigs until the answer is found (# of tests)


