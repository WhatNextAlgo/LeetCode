from typing import List


class Solution:
    def maxProfit(self, k: int, prices: List[int]) -> int:
        profit = [[0 for i in range(k + 1)]
                 for j in range(len(prices))]
     
        # Profit is zero for the first
        # day and for zero transactions
        for i in range(1, len(prices)):
            
            for j in range(1, k + 1):
                max_so_far = 0
                
                for l in range(i):
                    max_so_far = max(max_so_far, prices[i] -
                                prices[l] + profit[l][j - 1])
                                
                profit[i][j] = max(profit[i - 1][j], max_so_far)
        
        return profit[len(prices) - 1][k]

    def maxProfit(self, k: int, prices: List[int]):
        # Table to store results of subproblems
        # profit[t][i] stores maximum profit
        # using atmost t transactions up to
        # day i (including day i)
        n = len(prices)
        profit = [[0 for i in range(n + 1)]
                    for j in range(k + 1)]
    
        # Fill the table in bottom-up fashion
        for i in range(1, k + 1):
            prevDiff = float('-inf')
            
            for j in range(1, n):
                prevDiff = max(prevDiff,
                            profit[i - 1][j - 1] -
                            prices[j - 1])
                profit[i][j] = max(profit[i][j - 1],
                                prices[j] + prevDiff)
    
        return profit[k][n - 1]

s = Solution()
print(s.maxProfit(k = 2, prices = [3,2,6,5,0,3]))