import heapq
from typing import List


class Solution:
    def maxPerformance(self, n: int, speed: List[int], efficiency: List[int], k: int) -> int:
        eng = [(e,s) for e,s in zip(efficiency,speed)]
        eng.sort(key=lambda x : -x[0])
        
        res, speed = 0,0
        minHeap =[]
        for eff, spd in eng:
            if len(minHeap) == k:
                speed -= heapq.heappop(minHeap)
            speed += spd
            heapq.heappush(minHeap,spd)
            res = max(res,eff *speed)

        return res % (10 ** 9 + 7)



s = Solution()
print(s.maxPerformance(n = 6, speed = [2,10,3,1,5,8], efficiency = [5,4,3,9,7,2], k = 2))