
from collections import defaultdict, deque
from typing import List


class Solution:
    def findLadders(self, beginWord: str, endWord: str, wordList: List[str]) -> List[List[str]]:
        d = defaultdict(list)
        for word in wordList:
            for i in range(len(word)):
                d[word[:i]+"*"+word[i+1:]].append(word)

        if endWord not in wordList:
            return []

        visited1 = defaultdict(list)
        q1 = deque([beginWord])
        visited1[beginWord] = []

        visited2 = defaultdict(list)
        q2 = deque([endWord])
        visited2[endWord] = []

        ans = []
        def dfs(v, visited, path, paths):
            path.append(v)
            if not visited[v]:
                if visited is visited1:
                    paths.append(path[::-1])
                else:
                    paths.append(path[:])
            for u in visited[v]:
                dfs(u, visited, path, paths)
            path.pop()

        def bfs(q, visited1, visited2, frombegin):
            level_visited = defaultdict(list)
            for _ in range(len(q)):
                u = q.popleft()

                for i in range(len(u)):
                    for v in d[u[:i]+"*"+u[i+1:]]:
                        if v in visited2:
                            paths1 = []
                            paths2 = []
                            dfs(u, visited1, [], paths1)
                            dfs(v, visited2, [], paths2)
                            if not frombegin:
                                paths1, paths2 = paths2, paths1
                            for a in paths1:
                                for b in paths2:
                                    ans.append(a+b)
                        elif v not in visited1:
                            if v not in level_visited:
                                q.append(v)
                            level_visited[v].append(u)
            visited1.update(level_visited)

        while q1 and q2 and not ans:
            if len(q1) <= len(q2):
                bfs(q1, visited1, visited2, True)
            else:
                bfs(q2, visited2, visited1, False)

        return ans


# class Solution:
#     		def findLadders(self, beginWord: str, endWord: str, wordList: List[str]) -> List[List[str]]:
# 			res = []
# 			edge = collections.defaultdict(set)
# 			wordList = set(wordList)
# 			for word in wordList:
# 				for i in range(len(word)):
# 					edge[word[:i] +'*'+word[i+1:]].add(word)
# 			bfsedge = {}

# 			def bfs():
# 				minl = 0
# 				queue = set()
# 				queue.add(beginWord)
# 				while queue:
# 					next_queue = set()
# 					for word in queue:
# 						if word in wordList:
# 							wordList.remove(word)
# 					bfsedge[minl] = collections.defaultdict(set)
# 					for word in queue:
# 						if word == endWord:
# 							return minl
# 						for i in range(len(word)):
# 							for w in edge[word[:i]+'*'+word[i+1:]]:
# 								if w in wordList:
# 									next_queue.add(w)
# 									bfsedge[minl][w].add(word)
# 					queue = next_queue
# 					minl += 1
# 				return minl

# 			def dfs(seq, endWord):
# 				if seq[-1] == endWord:
# 					res.append(seq.copy())
# 					return
# 				for nextWord in bfsedge[minl-len(seq)][seq[-1]]:
# 					if nextWord not in seq:
# 						dfs(seq+[nextWord], endWord)

# 			minl = bfs()
# 			dfs([endWord], beginWord)
# 			# reverse the sequence
# 			for sq in res:
# 				sq.reverse()
# 			return res

# from collections import deque
# 	class Solution:
# 		def findLadders(self, beginWord: str, endWord: str, wordList: List[str]) -> List[List[str]]:
# 			if endWord not in wordList:return []
# 			wordList.append(beginWord)
# 			wordList.append(endWord)
# 			distance = {}


# 			self.bfs(endWord, distance, wordList)

# 			results = []
# 			self.dfs(beginWord, endWord, distance, wordList, [beginWord], results)

# 			return results

# 		def bfs(self, start, distance, w):
# 			distance[start] = 0
# 			queue = deque([start])
# 			while queue:
# 				word = queue.popleft()
# 				for next_word in self.get_next_words(word, w):
# 					if next_word not in distance:
# 						distance[next_word] = distance[word] + 1
# 						queue.append(next_word)

# 		def get_next_words(self, word, w):
# 			words = []
# 			for i in range(len(word)):
# 				for c in 'abcdefghijklmnopqrstuvwxyz':
# 					next_word = word[:i] + c + word[i + 1:]
# 					if next_word != word and next_word in w:
# 						words.append(next_word)
# 			return words

# 		def dfs(self, curt, target, distance, w, path, results):
# 			if curt == target:
# 				results.append(list(path))
# 				return

# 			for word in self.get_next_words(curt, w):
# 				if distance[word] != distance[curt] - 1:
# 					continue
# 				path.append(word)
# 				self.dfs(word, target, distance, w, path, results)
# 				path.pop()

s = Solution()
print(s.findLadders(beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]))