from typing import List
class Solution:
    def maxDepthAfterSplit(self, seq: str) -> List[int]:
        mid = len(seq) //2
        pass


s = Solution()
print(s.maxDepthAfterSplit(seq = "(()())"))


