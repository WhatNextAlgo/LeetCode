import math
#Linear Searching 
def linearSeach(alist,value):
    for x in range(len(alist)):
        if alist[x] == value:
            return x
    
    return -1


def binarySearch(alist,value):
    start = 0
    end= len(alist) -1
    middle = math.floor((start+end)/2)
    print(start,middle,end)
    while not (alist[middle] == value) and start <= end:
        if value < alist[middle]:
            end = middle -1
        else:
            start = middle + 1

        middle = math.floor((start+end)/2)
        print(start,middle,end)
    if alist[middle] == value:
        return middle
    else:
        return -1





if __name__ == "__main__":
    lst = [2,4,21,1,3,54,23,43,7]
    print(linearSeach(lst,7))
    lst1 = [1,2,3,4,5,6,7,8,9]
    print(binarySearch(lst1,10))
