import numpy as np
#Question 1- Missing Number

def findMissingNumber(lst, n):

    sum_of_n = (n * (n + 1))/2 

    missing_no = sum_of_n - sum(lst)
    print(missing_no)

#Question 2 -write a program to fina all pairs of integers who sum is equal to given number

def findPairs(lst,target):
    for i in range(len(lst)):
        for j in range(i + 1,len(lst)):
            if lst[i] == lst[j]:
                continue
            elif lst[i] + lst[j] == target:
                print(f"first index = {i} and second index = {j} and first val = {lst[i]} and second val = {lst[j]}")

#Question 3 - find a nummber in a given array

def findNumber(arr,target):
    for x in arr:
        if x == target:
            return True
    return False

#Questio n 4 - Max product of two integers in the given array where all elements are positive
def maxProductTwoNums(lst):
    max_product_so_far = 0
    for x in range(len(lst)):
        for y in range(x + 1,len(lst)):
            if lst[x] * lst[y] > max_product_so_far:
                max_product_so_far = lst[x] * lst[y]
                pairs = f"{lst[x]} , {lst[y]} "

    print(pairs)
    print(max_product_so_far)   

#Question 5 - Is unique:Implement an Algorithm to determine if list has unique characters using python list

def isUnique(lst):
    d = []
    for x in lst:
        if x in d:
            print(x)
            return False
        else:    
            d.append(x) 
    return True

def isPermutation(lst1,lst2):
    if len(lst1) != len(lst2):
        return False
    lst1.sort()
    lst2.sort()
    if lst1 == lst2:
        return True
    else:
        return False

#Rotate matrix - Given an Image by an NxN matrix  write a method to rotate the image by 90 degress

def rotateMatrixBy90(matrix):
    n = len(matrix)
    print("n for layer",n,n//2)

    for layer in range(n//2):
        first = layer
        last = n -layer - 1
        for i in range(first,last):
            #save top element
            top  = matrix[layer][i]
            # move left elemnt to top
            matrix[layer][i] = matrix[-i-1][layer]
            #move the bottom element of left
            matrix[-i-1][layer] = matrix[-layer-1][-i-1]
            #move right to bottom 
            matrix[-layer-1][-i-1] = matrix[i][-layer -1]
            #move top to right
            matrix[i][-layer -1] = top

    return matrix

    

if __name__ == "__main__":
    lst = [1,2,3,4,5,6,7,8,9,10]
    myArray = np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,30])
    twoDArray = np.array([[1,2,3],[4,5,6],[7,8,9]])
    print(twoDArray)
    #findMissingNumber(lst,len(lst)+1)
    #findPairs(lst,6)
    #print(findNumber(myArray,0))
    #maxProductTwoNums(myArray)
    #print(isUnique(myArray))
    #print(isPermutation([1,2,3],[3,0,1]))
    print(rotateMatrixBy90(twoDArray))
