class CricularQueue:
    def __init__(self,size):
        self.size = size
        self.top = -1
        self.start = -1
        self.items = [None] * size



    def enqueue(self,value):
        if self.is_full():
            return "Queue is full"
        else:
            if self.top + 1 == self.size:
                self.top = 0
            else:
                self.top +=1
                if self.start == -1:
                    self.start =0
            self.items[self.top] = value

    def dequeue(self):
        if self.is_empty():
            return "Queue is empty"
        else:
            first_elem = self.items[self.start]
            start = self.start
            if self.start == self.top:
                self.start = -1 
                self.top = -1
            elif self.start + 1 == self.size:
                self.start = 0
            else:
                self.start +=1

            self.items[start] = None
            return first_elem

    def is_full(self):
        if self.top + 1 == self.start:
            return True
        elif self.start == 0 and self.top + 1 == self.size:
            return True
        else:
            return False

    def is_empty(self):
        if self.top == -1:
            return True
        else:
            return False

    def delete(self):
        self.items = self.size * [None]
        self.start = -1
        self.top = -1

    def peek(self):
        if self.is_empty():
            return "Queue is empty"
        else:
            return self.items[self.start]

        

    def __str__(self):
        values = [str(x) for x in self.items]
        return "-->".join(values)

if __name__ == "__main__":
    c = CricularQueue(3)
    print(c.is_full())
    c.enqueue(1)
    c.enqueue(2)
    c.enqueue(3)
    print(c)
    print(c.is_full())
    print(c.dequeue())
    print(c)
    print(c.peek())
    c.delete()
    print(c)
