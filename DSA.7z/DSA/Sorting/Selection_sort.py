
def selectionSort(alist):
    
    for x in range(len(alist)):
        min_index = x
        for y in range(x + 1, len(alist)):
            if alist[min_index] > alist[y]:
                min_index = y
        alist[x],alist[min_index] = alist[min_index],alist[x]
    print(alist)

if __name__=="__main__":
    lst = [11,2,3,7,6,8,9]
    selectionSort(lst)