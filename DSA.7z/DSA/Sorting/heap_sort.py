def heapify(alist,n,i):
    smallest = i
    l = 2 * i + 1
    r = 2 * i + 2
    if l < n and alist[l] < alist[smallest]:
        smallest = l
    
    if r < n and alist[r] < alist[smallest]:
        smallest = r

    if smallest != i:
        alist[i],alist[smallest] = alist[smallest],alist[i]
        heapify(alist,n,smallest)

def heapSort(alist):
    n = len(alist)
    for i in range(int(n/2)-1,-1,-1):
        heapify(alist,n,i)

    for i in range(n-1,0,-1):
        alist[i], alist[0] = alist[0],alist[i]
        heapify(alist,i,0)

    alist.reverse()


if __name__ == "__main__":
    lst = [11,2,3,7,6,8,9]
    heapSort(lst)
    print(lst)