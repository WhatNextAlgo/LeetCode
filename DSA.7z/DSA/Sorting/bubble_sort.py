
def bubbleSort(alist):

    for x in range(len(alist)-1):
        for y in range(len(alist)-x-1):
            if alist[y] > alist[y + 1]:
                alist[y],alist[y + 1] = alist[y + 1] , alist[y]

    print(alist)



if __name__ == "__main__":
    lst = [11,3,5,2,7,8,9]
    bubbleSort(lst)