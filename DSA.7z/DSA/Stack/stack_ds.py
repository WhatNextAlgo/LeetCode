class Stack:
    def __init__(self):
        self.items = []

    def peek(self):
        if not self.is_empty():
            return self.items[-1]
        return None

    def is_empty(self):
        return self.items == []

    def clear(self):
        self.items = []

    def __str__(self):
        values = [str(x) for x in self.items]
        return "-->".join(values)
            

    def push(self,value):
        self.items.append(value)

    def pop(self):
        if not self.is_empty():
            return self.items.pop()


if __name__ == "__main__":
    s = Stack()
    s.push(1)
    s.push(2)
    s.push(3)
    print(s)
    print(s.pop())
    print(s)
    print(s.peek())
