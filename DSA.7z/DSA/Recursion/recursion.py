#Implement  factorial for any given value

def factorial(n):
    assert n >= 0 and int(n) == n, 'The number must be positive integer only!'
    #base condition
    if n in [0,1]:
        return 1
    return n * factorial(n-1) # recursivly call factorial function with n-1 paramter


def fibonacci(n):
    assert n >= 0 and int(n) == n, 'fibonacci  number cannot be negative number or non integer.'
    #base condition
    if n in [0,1]:
        return n
    return fibonacci(n-1) + fibonacci(n-2)  # recursivly call fibonacci function with n-1 an n-2 paramter


#How to find the sum of digits of a positive integer number using recursion
#step 1 : Recursive case -flow
# 10   10/10  = 1 and remainder 0
# 54   54/10  = 5 and remainder 4
# 112  112/10 = 11 and remainder 2
#      11/10  = 1 and remainder 0 

def sum_of_digit(n):
    assert n >= 0 and int(n) == n, 'The number has to be positive integer only'
    #base conditon
    if n ==0:
        return 0
    return n%10 + sum_of_digit(int(n/10)) 


#how to calculate power of a number using recursion
#case 
#(-1,4)
#(3.2,4)
#(2,-1) failed
#(2,1.1)

def power(base,exp):
    assert exp >= 0 and int(exp) == exp, 'The exponent number must be positive integer only'
    #base condition
    if exp == 0:
        return 1
    if exp == 1:
        return base
    return base * power(base,exp-1)

#how to find GCD of two given number using recursion
#GCD(48/18) by eucildean algorithm
#1. 48/18 = 2 reminder 12
#2. 18/12 = 1 remainder 6
#3. 12/6  = 2 remainder 0

def gcd(a,b):
    assert int(a) == a and int(b) == b, "the number must be integer only!"

    if a < 0:
        a = -1 * a
    if b < 0:
        b = -1 * b
    # base condition
    if b == 0:
        return a
    return gcd(b,a % b)

#how to convert a number from decimal to binary number using recursion
#1.Divide the number by 2
#2. get the integer quotient for the iteration
#3. Get the reminder by binary
#4. repeat the process until the quotient is equal to 00
#0 + 10 * convert_decimal_to_binary(5) => 0 + 10 * 101 = 1010
#1 + 10 * convert_decimal_to_binary(2)=>1 + 10 * 10 = 101
#0 + 10 * convert_decimal_to_binary(1) => 0 + 10 * 1 = 10
#1 + 10 * convert_decimal_to_binary(0) => 1 + 10 * 0 = 1


def convert_decimal_to_binary(n):
    assert int(n) == n, 'The number must be  integer only!'
    #base condition
    if n == 0:
        return 0
    return n % 2 + 10 * convert_decimal_to_binary(int(n/2))


if __name__ == "__main__":
    #print(factorial(4))
    #print(fibonacci(1))
    #print(sum_of_digit(112))
    #print(power(-1,4))
    #print(gcd(-48,-18))
    print(convert_decimal_to_binary(-10))
