class Graph:
    def __init__(self,gdict =None):
        self.gdict = gdict if gdict is not None else {}

    
    def bfs(self,start,end):
        queue = []
        queue.append([start])
        while queue:
            path = queue.pop(0)
            node = path[-1]
            print(path)
            print(node)
            if node == end:
                return path
            for adjacent in self.gdict.get(node,[]):
                new_path  = list(path)
                new_path.append(adjacent)
                queue.append(new_path)


if __name__ == "__main__":
    customDict = {
        "a" : ["b","c"],
        "b" : ["d","g"],
        "c" : ["d","e"],
        "d" : ["f"],
        "e" : ["f"],
        "f" : ["f"]
    }

    graph = Graph(customDict)
    print(graph.bfs("a","e"))