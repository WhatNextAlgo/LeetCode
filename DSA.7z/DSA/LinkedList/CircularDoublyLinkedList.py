
from typing import NewType


class Node:
    def __init__(self,value):
        self.value = value
        self.prev = None
        self.next = None


class CircularDoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None


    def is_empty(self):
        return self.head is None

    def get_length(self):
        curr = self.head
        count = 0
        while curr:
            count +=1
            if curr.next == self.head:
                break
            curr = curr.next
        return count

    def __iter__(self):
        curr = self.head
        while curr:
            yield curr
            if curr.next == self.head:
                break
            curr = curr.next

    def traverse(self):
        if self.head is None:
            print("CircularDoublyLinkedList does not exist")
        else:
            curr = self.head
            while curr:
                print(curr.value, end = ", ")
                curr = curr.next
                if curr == self.head:
                    break

    def reverse_traverse(self):
        if self.head is None:
            print("CircularDoublyLinkedList does not exist")
        else:
            curr = self.tail
            while curr:
                print(curr.value, end = ", ")
                if curr == self.head:
                    break
                curr = curr.prev

    def search(self,value):
        if self.head is None:
            return None
        else:
            curr = self.head
        while curr:
            if curr.value == value:
                return curr.value
            if curr == self.tail:
                break
            curr = curr.next

        return None

    def clear(self):
        if not self.is_empty():
            self.tail.next = None
            curr = self.head
            while curr:
                curr.prev = None
                curr = curr.next

            self.head =None
            self.tail =None
        
        



    def insert_at_beginning(self,value):
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
            self.tail = new_node
            new_node.prev = new_node
            new_node.next = new_node
        else:
            new_node.next = self.head
            new_node.prev = self.tail
            self.head.prev = new_node
            self.tail.next = new_node
            self.head = new_node
            


    def insert_at_end(self,value):
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
            self.tail = new_node
            new_node.prev = new_node
            new_node.next = new_node
        else:
            new_node.next = self.head
            new_node.prev = self.tail
            self.head.prev= new_node
            self.tail.next = new_node
            self.tail = new_node

    def insert_at_index(self,value,location):
        if location >= self.get_length():
            print("Index out of range")
        else:
            curr = self.head
            index = 0
            new_node = Node(value)
            while index < location -1:
                curr = curr.next
                index +=1

            if index == location:
                self.insert_at_beginning(value)
            else:
                new_node.next = curr.next
                new_node.prev = curr
                new_node.next.prev = new_node
                curr.next = new_node


    


    def delete_at_beginning(self):
        if not self.is_empty():
            if self.head == self.tail:
                self.head = None
                self.tail = None
                self.head.prev = None
                self.tail.next = None
            else:
                next_node = self.head.next
                self.head.next = None
                self.head.prev = None
                self.head = next_node
                next_node.prev = self.tail
                self.tail.next = next_node

    def delete_at_end(self):
        if not self.is_empty():
            if self.head == self.tail:
                self.head = None
                self.tail = None
                self.head.prev = None
                self.tail.next = None
            else:
                prev = self.tail.prev
                self.tail.prev =None
                self.tail.next =None
                prev.next = self.head
                self.head.prev = prev
                self.tail = prev

    def delete_at_index(self,location):
        if location >= self.get_length():
            print("Index out of range")
        else:
            curr = self.head
            index = 0
            while index < location -1:
                curr =curr.next
                index +=1

            if index == location:
                self.delete_at_beginning()
            elif  location == self.get_length() -1:
                self.delete_at_end()
            else:
                next_node = curr.next
                curr.next = next_node.next
                next_node.next.prev = curr

            



    



if __name__ == "__main__":
    cd = CircularDoublyLinkedList()

    cd.insert_at_end(2)
    cd.insert_at_beginning(0)
    cd.insert_at_index(1,1)

    print([node.value for node in cd])
    cd.insert_at_index(3,2)
    #print([node.value for node in cd])
    #cd.traverse()
    #print()
    #cd.reverse_traverse()
    #print(cd.search(3))
    print(cd.is_empty())
    print([node.value for node in cd])
    #cd.delete_at_beginning()
    #cd.delete_at_end()
    #cd.delete_at_index(0)
    cd.clear()
    print([node.value for node in cd])
