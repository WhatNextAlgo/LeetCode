
from LinkedList import LinkedList,Node

#Question -1 : Remove Duplicates from a LinkedList 
def remove_duplicates(ll):
    if ll.head is None:
        return
    else:
        curr = ll.head
        visited = set([curr.value])
        while curr.next:
            if curr.next.value in visited:
                curr.next = curr.next.next
            else:
                visited.add(curr.next.value)
                curr = curr.next

    return ll

def remove_duplicates_withTemp(ll):
    if ll.head is None:
        return
    
    curr = ll.head
    while curr:
        runner = curr
        while runner.next:
            if runner.next.value == curr.value:
                runner.next = runner.next.next
            else:
                runner = runner.next
        curr = curr.next
    return ll




#Question -2 : Return Nth to last (find the nth to last element of a singly linked list)

def nth_to_last(ll,n):
    p1  = ll.head
    p2 = ll.head

    for i in range(n):
        if p2 is None:
            return None
        p2 =  p2.next

    while p2:
        p1 = p1.next
        p2 = p2.next
    return p1




#Question -3 : Parition LinkedList

def partition_linkedlist(ll,x):
    curr = ll.head
    ll.tail = ll.head

    while curr:
        next_node = curr.next
        curr.next = None
        if curr.value < x:
            curr.next = ll.head
            ll.head = curr
        else:
            ll.tail.next = curr
            ll.tail = curr
        curr= next_node
    if ll.tail.next is not None:
        ll.tail.next = None

    return ll


#Question -4 :Sum Lists
def addLL(lst1,lst2):
    n1 = lst1.head
    n2 = lst2.head
    carry = 0
    ll = LinkedList()

    while n1 or n2:
        result= carry
        if n1:
            result += n1.value
            n1 = n1.next
        if n2:
            result += n2.value
            n2 = n2.next

        ll.add(int(result%10))
        carry = result / 10

    return ll


#Question -5 :Intersection

def intersect_node(lst1,lst2):
    if lst1.tail is not lst2.tail:
        return
    lenA = len(lst1) 
    lenB = len(lst2)
    shorter = lst1 if lenA < lenB else lst2
    longer = lst2 if lenA < lenB else lst1

    diff = len(longer) - len(shorter)
    longerNode = longer.head
    shorterNode = shorter.head

    for i in range(diff):
        longerNode = longerNode.next

    while shorterNode is not longerNode:
        shorterNode = shorterNode.next
        longerNode = longerNode.next

    return longerNode

#Helper additon method
def addSample(lst1,lst2,value):
    tempNode = Node(value)
    lst1.tail.next = tempNode
    lst1.tail = tempNode

    lst2.tail.next = tempNode
    lst2.tail = tempNode

    pass
if __name__ == "__main__":
    customLL = LinkedList()
    customLL.generate(10,0,99)
    print(customLL)
    #print(remove_duplicates(customLL))
    #print(remove_duplicates_withTemp(customLL))
    #print(nth_to_last(customLL,3))
    #print(partition_linkedlist(customLL,30))
    # lst1 = LinkedList()
    # lst1.add(7)
    # lst1.add(1)
    # lst1.add(6)

    # lst2 = LinkedList()
    # lst2.add(5)
    # lst2.add(9)
    # lst2.add(2)
    # print(lst1)
    # print(lst2)
    # print(addLL(lst1,lst2))

    llA = LinkedList()
    llA.generate(3,0,10)

    llB = LinkedList()
    llB.generate(4,0,10)

    addSample(llA,llB,11)
    addSample(llA,llB,14)
    print(llA)
    print(llB)

    print(intersect_node(llA,llB))