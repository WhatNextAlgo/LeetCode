
from typing import NewType


class Node:
    def __init__(self,value):
        self.value = value
        self.prev = None
        self.next = None


class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def __iter__(self):
        curr = self.head
        while curr:
            yield curr
            curr = curr.next

    def get_length(self):
        curr = self.head
        count = 0
        while curr:
            count +=1
            curr = curr.next
        return count


    def traverse(self):
        curr = self.head
        while curr:
            print(curr.value, end=", ")
            curr = curr.next

    def clear(self):
        if self.head is None:
            return None
        curr = self.head
        while curr:
            curr.prev = None
            curr = curr.next 
        
        self.head = None
        self.tail =None

    def reverse_traverse(self):
        if self.head is None:
            return "DoublyLinkedlist does not exist"
        else:
            curr = self.tail
            while curr:
                print(curr.value, end =", ")
                curr = curr.prev

    def search(self,value):
        if self.head is None:
            return None

        curr = self.head
        while curr:
            if curr.value == value:
                return curr.value
            curr =curr.next
        return f"{value} does not exist in DoublyLinkedList" 
    
    def insert_at_beginning(self,value):
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node


    def insert_at_end(self,value):
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            new_node.prev = self.tail
            self.tail = new_node

    def insert_at_index(self,value,location):
        if location >= self.get_length():
            print("Index out of range")
        else:
            new_node = Node(value)
            curr = self.head
            index = 0
            while index < location -1:
                curr = curr.next
                index +=1

            next_node = curr.next
            curr.next = new_node
            new_node.prev = curr
            new_node.next = next_node
            next_node.prev = new_node



    def delete_at_beginning(self):
        if self.head is None:
            return "DoublyLinkedList does not exist"
        else:
            if self.head == self.tail:
                self.head.prev = None
                self.head.next = None
                self.head = None
                self.tail = None
            else:
                self.head = self.head.next
                self.head.prev = None

    def delete_at_end(self):
        if self.head is None:
            print("DoublyLinkedList does not exist")
        else:
            if self.head == self.tail:
                self.head.prev = None
                self.head.next = None
                self.head = None
                self.tail = None
            else:
                self.tail = self.tail.prev
                self.tail.next = None


    def delete_at_index(self,location):
            if location >= self.get_length():
                print("Index out of range")
            else:
                curr = self.head
                index = 0
                while index < location -1:
                    curr = curr.next
                    index +=1

                if index == location:
                    self.delete_at_beginning()
                
                if curr.next.next is None:
                    self.delete_at_end()
                else:
                    curr.next = curr.next.next
                    curr.next.prev = curr



                



if __name__ == "__main__":
    d = DoublyLinkedList()
    d.insert_at_end(2)
    d.insert_at_beginning(0)
    d.insert_at_index(1,1)
    d.insert_at_end(4)
    d.insert_at_index(3,3)
    #d.traverse()
    #print()
    #d.reverse_traverse()
    #print()
    print([node.value for node in d])
    #print(d.search(7))
    #d.delete_at_index(5)
    #d.delete_at_beginning()
    #d.delete_at_end()
    d.clear()
    print([node.value for node in d])
    
