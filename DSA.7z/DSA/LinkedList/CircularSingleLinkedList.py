class Node:
    def __init__(self,value):
        self.value = value
        self.next = None

class CircularSinglyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def __iter__(self):
        curr = self.head
        while curr:
            yield curr
            if curr.next == self.head:
                break
            curr = curr.next

    def get_length(self):
        curr = self.head
        count = 0
        while curr:
            count +=1
            if curr.next == self.head:
                break
            curr = curr.next
        return count

        
    def insert_at_end(self,value):
        new_node = Node(value)

        if self.head is None:
            new_node.next = new_node
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.tail.next
            self.tail.next = new_node
            self.tail = new_node
    
    def insert_at_beginning(self,value):
        new_node = Node(value)
        if self.head is None:
            new_node.next = new_node
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head = new_node
            self.tail.next = new_node

    def insert_at_index(self,value,location):
        if location >= self.get_length():
            print("Index out of range")
            return
        curr = self.head
        new_node = Node(value)
        index = 0

        while index < location -1:
            curr = curr.next
            index +=1

        next_node = curr.next
        curr.next =  new_node
        new_node.next = next_node

    def traverseCSLL(self):
        curr = self.head
        while curr:
            print(curr.value,end=" ")
            if curr.next == self.head:
                break
            curr = curr.next

    def searchCSLL(self,value):
        if self.head is None:
            return "CircularSinglyLinkedList is does not exist"
        else:
            curr = self.head
            while curr:
                if curr.value == value:
                    return curr.value
                curr = curr.next
                if curr == self.tail.next:
                    break
        return "Element is not present in CircularSinglyLinkedList"


    def deleteCSLL(self,location):
        if self.head is None:
            print("CircularSinglyLinkedList is does not exist")
        if location == 0:
            if self.head == self.tail:
                self.head.next = None
                self.head = None
                self.tail =None
            else:
                self.head = self.head.next
                self.tail.next = self.head

        elif location == 1:
            if self.head == self.tail:
                self.head.next = None
                self.head = None
                self.tail =None
            else:
                curr = self.head
                while curr is not None:
                    if curr.next == self.tail:
                        break
                    curr = curr.next
                curr.next = self.head
                self.tail = curr

        else:
            if location >= self.get_length():
                print("Index out of range")
                return
            curr = self.head
            index = 0
            while index < location - 1:
                curr = curr.next
                index +=1

            next_node = curr.next
            curr.next= next_node.next


    def clear(self):
        self.head =None
        self.tail.next = None
        self.tail =None


                    

if __name__ == "__main__":
    c = CircularSinglyLinkedList()
    c.insert_at_end(2)
    c.insert_at_beginning(0)
    c.insert_at_index(1,1)
    print(c.get_length())
    c.insert_at_index(3,2)
    #print([node.value for node in c])
    #c.traverseCSLL()
    #print(c.searchCSLL(0))
    print([node.value for node in c])
    #c.deleteCSLL(0)
    #c.deleteCSLL(1)
    #c.deleteCSLL(2)
    c.clear()
    print([node.value for node in c])
