from array import *
import numpy as np


# print(arr1)
# print(arr2)

# arr1.insert(5,6)
# print(arr1)
# arr1.insert(0,10)
# print(arr1)
# arr1.insert(10,11)
# print(arr1[7])


def iteration_array(arr):
    for i,x in enumerate(arr):
        print(i,"=",x)


def accessElement(arr,index):
    if index >=  len(arr):
        print("There is not any elemnet  in this index")
    else:
        print(arr[index])




def searchElemnt(arr,elem):
    for x in arr:
        if x == elem:
            return x
    return "The element does not exist in this array"

def traverseTwoDArray(arr):
    row = arr.shape[0]
    column = arr.shape[1]

    for r in range(row):
        for c in range(column):
            print(arr[r][c],end=" ") 
        print()


def accessElementTwoDArray(arr,row,column):
    if row >= arr.shape[0] or column >= arr.shape[1]:
        print("the element is not present in two Dim Array")
    else:
        print(arr[row][column])

    

def searchElemntTwoDArray(arr,val):
    row = arr.shape[0]
    column = arr.shape[1]

    for r in range(row):
        for c in range(column):
            if arr[r][c] == val:
                return f"The value is loacted at row index = {r} and column index = {c}  for value {arr[r][c]}"
    
    return "Element does not exit in two dim array"


if __name__ == '__main__':
    arr1 = array('i',[1,2,3,4,5])
    arr2 = array('d',[1.4,2.4,3.3,4.2,5.1])
    #iteration_array(arr1)
    #accessElement(arr1,8)
    #print(searchElemnt(arr1,11))
    #arr1.remove(1)
    #print(arr1)

    #two dimension array
    twoDArray = np.array([[11,15,10,6],\
                          [10,14,11,5],\
                          [12,17,12,8],\
                          [15,18,14,9]])
    traverseTwoDArray(twoDArray)
    # axis = 0 => adding in row 
    # axis = 1 => adding in column
    newTwoDArray = np.insert(twoDArray,0,[[1,2,3,4]],axis=0)
    #print(newTwoDArray)
    accessElementTwoDArray(twoDArray,1,2)
    print(searchElemntTwoDArray(twoDArray,5))

    newTwoDArrayWhenDeleted = np.delete(twoDArray,0,axis=0)
    print(newTwoDArrayWhenDeleted)