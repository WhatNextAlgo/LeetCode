import QueueLinkedList as queue
import sys
sys.setrecursionlimit(30)
class BSTNode:
    def __init__(self,data):
        self.data =data
        self.leftChild = None
        self.rightChild = None


def insertNode(rootNode,nodeValue):
    if rootNode.data == None:
        rootNode.data = nodeValue
    elif nodeValue <= rootNode.data:
        if rootNode.leftChild is None:
            rootNode.leftChild = BSTNode(nodeValue)
        else:
            insertNode(rootNode.leftChild,nodeValue)
    else:
        if rootNode.rightChild is None:
            rootNode.rightChild = BSTNode(nodeValue)
        else:
            insertNode(rootNode.rightChild,nodeValue)

    return "Node successfully inserted"


def searchBST(rootNode,value):
    if rootNode is not None:
        if  rootNode.data == value:
            return "The Value is found"
        elif value < rootNode.data:
            if rootNode.leftChild and rootNode.leftChild.data == value:
                return "The Value is found"
            else:
                searchBST(rootNode.leftChild,value)
        else:
            if rootNode.rightChild and rootNode.rightChild.data == value:
                return "The Value is found"
            else:
                searchBST(rootNode.rightChild,value)

    
    return "The Value is not found"

def minValueNode(rootNode):
    curr  = rootNode
    while curr.leftChild is not None:
        curr = curr.leftChild

    return curr

def deleteNode(rootNode,nodeValue):
    if rootNode is None:
        return rootNode

    if nodeValue < rootNode.data:
        rootNode.leftChild = deleteNode(rootNode.leftChild,nodeValue)
    elif nodeValue > rootNode.data:
        rootNode.rightChild = deleteNode(rootNode.rightChild,nodeValue)
    else:
        if rootNode.leftChild is None:
            temp = rootNode.leftChild
            rootNode = None
            return temp

        if rootNode.rightChild is None:
            temp = rootNode.rightChild
            rootNode = None
            return temp
        
        temp = minValueNode(rootNode.rightChild)
        rootNode.data = temp.data
        rootNode.rightChild = deleteNode(rootNode.rightChild,temp.data)
    
    return rootNode


def deleteBST(rootNode):
    rootNode.data = None
    rootNode.leftChild = None
    rootNode.rightChild = None


        



def preorder(rootNode):
    if rootNode is None:
        return
    print(rootNode.data,end=" ")
    preorder(rootNode.leftChild)
    preorder(rootNode.rightChild)

def inorder(rootNode):
    if rootNode is None:
        return
    inorder(rootNode.leftChild)
    print(rootNode.data,end=" ")
    inorder(rootNode.rightChild)


def postorder(rootNode):
    if rootNode is None:
        return
    postorder(rootNode.leftChild)
    postorder(rootNode.rightChild)
    print(rootNode.data,end=" ")


def levelorder(rootNode):
    if not rootNode:
        return
    else:
        customQueue = queue.Queue()
        customQueue.enqueue(rootNode)
        while not customQueue.is_empty():
            root = customQueue.dequeue()
            print(root.data,end=" ")
            if root.leftChild is not None:
                customQueue.enqueue(root.leftChild)
            
            if root.rightChild is not None:
                customQueue.enqueue(root.rightChild)
            


if __name__ == "__main__":
    bst = BSTNode(None)
    print(insertNode(bst,70))
    print(insertNode(bst,50))
    print(insertNode(bst,60))
    print(insertNode(bst,80))
    print(insertNode(bst,40))
    print(insertNode(bst,30))
    print(insertNode(bst,20))
    # preorder(bst)
    # print("-- preorder")
    # inorder(bst)
    # print("-- inorder")
    # postorder(bst)
    # print("-- postorder")
    # levelorder(bst)
    # print("-- leveloreder")
    # print(searchBST(bst,80))
    levelorder(bst)
    print("-- levelorder")
    deleteNode(bst,60)
    levelorder(bst)
    print("-- levelorder")
    deleteBST(bst)
    


